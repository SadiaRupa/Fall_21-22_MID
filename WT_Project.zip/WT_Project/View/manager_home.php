<html>

<body>
      <div align="center">
    <h2>Manager Dashboard</h2>
    <form action="" method="post">
<div>
  <table  align="center">
    <tr>
      <td>
        <div align = "center">
        <a href="http://localhost/Webtech/WT_Project/View/add_hotel_room.php"> Add Hotel Rooms <br></a>
        </div>
      </td>
	   <td>
        <div align = "center">
        <a href="http://localhost/Webtech/WT_Project/View/all_hotel_room.php"> All Hotel Rooms Info <br></a>
        </div>
      </td>
	  <td>
	  <div align = "center">
        <a href="http://localhost/Webtech/WT_Project/View/add_meals.php"> Add Hotel Meals <br></a>
        </div>
      </td>
	  <td>
	  <div align = "center">
        <a href="http://localhost/Webtech/WT_Project/View/all_meals.php"> All Hotel Meals Info <br></a>
        </div>
      </td>
	  <td>
	  <div align = "center">
        <a href="http://localhost/Webtech/WT_Project/View/all_emp.php"> All Employees Info <br></a>
        </div>
      </td>
      <td>
	  <div align = "center">
        <a href="http://localhost/Webtech/WT_Project/View/add_emp.php"> Add Employees <br></a>
        </div>
      </td>     
        <td>
            <div align="center"><p><a href="logout.php" >LOG OUT <br></a></div>
        </td>
    </tr>   
  </table>
</div>
</body>
</html>